--1. Database creation
use master 
if exists (select*from sys.databases where name = 'TheRideYouRent')
drop database TheRideYouRent
create DATABASE TheRideYouRent;
use TheRideYouRent

--2. table creation section
create table CarBodyType (
Id int identity (1,1) primary key not null,
[Description] varchar(60)
);

create table CarMake (
Id int identity (1,1) primary key not null,
[Description] varchar(60)
);

create table Car (
Id int identity (1,1) primary key not null,
CarNo varchar(60) unique,
CarMake int foreign key references CarMake(Id) not null,
Model varchar(60),
BodyType int foreign key references CarBodyType(Id) not null,
KilometresTravelled int,
ServiceKilometres int,
Available varchar (60)
);

create table Inspector (
Id int identity (1,1) primary key not null,
Inspector_no varchar(60),
[Name] varchar(60),
Email varchar (60),
Mobile varchar(10)
);

create table Driver (
Id int identity (1,1) primary key not null,
[Name] varchar(60),
[Address] varchar(60),
Email varchar(60),
Mobile varchar(10)
);

create table Rental (
Id int identity (1,1) primary key not null,
CarNo int foreign key references Car(Id) not null,
Inspector int foreign key references Inspector(Id) not null,
Driver int foreign key references Driver(Id) not null,
RentalFee int not null,
StartDate date,
EndDate date
);

create table [Return] (
Id int identity (1,1) primary key not null,
CarNo int foreign key references Car(Id) not null,
Inspector int foreign key references Inspector(Id) not null,
Driver int foreign key references Driver(Id) not null,
ReturnDate date,
ElapsedDate int,
Fine int
);


--3. table alteration section
--4. table insertion section
insert into CarMake
values ('Hyndai'),('BMW'),('Mercedes Benz'),('Toyota'),('Ford') 

insert into CarBodyType
values ('Hatchback'),('Sedan'),('Coupe'),('SUV')

insert into Car (CarNo, CarMake, Model, BodyType, KilometresTravelled, ServiceKilometres, Available)
values ('HYU001',1,'Grand i10 1.0 Motion',1,15000,15000,'yes'),
('HY002',1,'i20 1.2 Fluid',1,3000,15000,'yes'),
('BMW001',2,'320d 1.2',2,20000,50000,'yes'),
('BMW002',2,'240 1.4',2,9500,15000,'yes'),
('TOY001',4,'Corolla 1.0',2,15000,50000,'yes'),
('TOY002',4,'Avanza 1.0',4,98000,15000,'yes'),
('TOY003',4,'Corolla Quest 1.0',2,15000,50000,'yes'),
('MER001',3,'c180',2,5200,15000,'yes'),
('MER002',3,'A200 Sedan',2,4080,15000,'yes'),
('FOR001',5,'Fiesta 1.0',2,7600,15000,'yes')

insert into Inspector (Inspector_no, [Name], Email, Mobile)
values ('101','Bud Barnes','bud@therideyourent.com','082158359'),
('102','Tracy Reeves','tracy@therideyourent.com','0822889988'),
('103','Sandra Goodwin','sandra@therideyourent.com','0837695468'),
('104','Shannon Burke','shannon@therideyourent.com','0836802514')

insert into Driver([Name], [Address], Email, Mobile)
values ('Gabrielle Clarke','917 Heuvel St Botshabelo Free State 9781','gorix10987@macauvpn.com','0837113269'),
('Geoffrey Franklin','1114 Dorp St Paarl Western Cape 7655','noceti8743@drlatvia.com','0847728052'),
('Fawn Cooke','2158 Prospect St Garsfontein Gauteng 0042','yegifav388@enamelme.com','0821966584'),
('Darlene Peters','2529 St John Street Somerset West Western Cape 7110', 'mayeka4267@macauvpn.com','0841221244'),
('Vito Soto','1474 Wolmarans St Sundra Mpumalanga 2200','wegog55107@drlatvia.com','0824567924'),
('Opal Rehbein','697 Thutlwa St Letaba Limpopo 0870','yiyow34505@enpaypal.com','0826864938'),
('Vernon Hodgson','1935 Thutlwa St Letsitele Limpopo 0885','gifeh11935@enamelme.com','0855991446'),
('Crispin Wheatley','330 Sandown Rd Cape Town Western Cape 8018','likon78255@macauvpn.com','0838347945'),
('Melanie Cunningham','616 Loop St Atlantis Western Cape 7350','sehapeb835@macauvpn.com','0827329001'),
('Kevin Peay','814 Daffodil Dr Elliotdale Eastern Cape 5118','xajic53991@enpaypal.com','0832077149')

insert into Rental(CarNo, Inspector, Driver, RentalFee, StartDate, EndDate)
values(1,1,1,5000,'2021-08-30','2021-08-31'),
(2,1,1,5000,'2021-09-01','2021-09-10'),
(10,1,2,6500,'2021-09-01','2021-09-10'),
(4,2,5,7000,'2021-09-20','2021-09-25'),
(6,2,4,5000,'2021-10-03','2021-10-31'),
(8,3,4,8000,'2021-10-05','2021-10-15'),
(2,4,7,5000,'2021-12-01','2022-02-10'),
(7,4,9,5000,'2021-08-10','2021-08-31')

insert into [Return](CarNo,Inspector,Driver,ReturnDate,ElapsedDate,Fine)
values (1,1,1,'2021-08-31',0,0),
(2,1,1,'2021-09-10',0,0),
(10,1,2,'2021-09-10',0,0),
(4,2,5,'2021-09-30',5,2500),
(6,2,4,'2021-10-31',2,1000),
(8,3,4,'2021-10-15',1,500),
(2,4,7,'2022-02-10',0,0),
(7,4,9,'2021-08-31',0,0)

--5.query 1: will return rentals placed between 2021-08-01 and 2021-10-30
select * from Rental
where StartDate BETWEEN '2021-08-01' AND '2021-10-30'

--6 query 2: will return all rentals placed by 'Bud Barnes'
select * from Rental
where Inspector = 1

--7 query 3: will return all return car make for Toyota
select * from [Return]
where CarNo IN (5,6,7)  

--8 query 4: will count the number of rentals placed for car make Hyundai
select count(*) from Rental
where CarNo IN (1,2)

--9 query 5: will update the model of the car with the CarNo FOR001 from "Fiesta" to "Focus"
update Car
set Model = 'Focus'
where CarNo = 'FOR001'

--10 query 6: will display the CarNo, DriverName, RentalFee, StartDate, EndDate and Availability of all rentals
 select Rental.CarNo, Rental.Driver, Rental.RentalFee, Rental.StartDate, Rental.EndDate, Car.Available
 from Rental
 inner join Car on Rental.Id = Car.Id

 --11 query will display a list of the available car makes in database using the DISTINCT command
 select distinct CarMake
 from Car

 --12 will show the cars that will need service soon that have travelled 9000 kilometres away
select Id
from Car
where (ServiceKilometres - KilometresTravelled) <= 9000 

--13 query will calculae late fee
select [Return].ElapsedDate * 500 
as fine
from [Return]



